<?php
include 'db.php';

echo "Connected successfully!<br>";

$sql = "INSERT INTO users (name) VALUES ('Dhanashri')";
$conn->query($sql);

$result = $conn->query("SELECT * FROM users");

while($row = $result->fetch_assoc()) {
    echo $row['id'] . " - " . $row['name'] . "<br>";
}
?>