# LEMP Stack AWS Project

- EC2 (Ubuntu)
- Nginx
- PHP
- RDS MySQL

Features:
- Dynamic PHP app
- Database connectivity
- Cloud deployment
